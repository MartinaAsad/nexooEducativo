/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nexo.nexoeducativo.models.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author Martina
 */
@Data
public class AlumnoDTO extends UsuarioDTO implements Serializable{
    @NotNull(message="campo curso invalido")
    @Min(value = 0, message = "Valor invalido")
    @Max(value = 25, message = "Valor invalido")
    private int idCurso;
    
    @NotNull(message="campo padre invalido")
    @Min(value = 0, message = "Valor invalido")
    private int idPadre;
    
    
}
