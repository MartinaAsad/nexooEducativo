package com.nexo.nexoeducativo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexoeducativoApplicationTests {

	@Test
	void contextLoads() {
	}

}
