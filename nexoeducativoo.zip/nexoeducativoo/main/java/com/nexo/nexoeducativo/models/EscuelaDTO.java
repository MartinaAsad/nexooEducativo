package com.nexo.nexoeducativo.models.dto.request;

import com.nexo.nexoeducativo.models.entities.Plan;
import com.nexo.nexoeducativo.models.entities.Usuario;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.hibernate.validator.constraints.Length;



@Data
public class EscuelaDTO {
    @Pattern(regexp = "^[a-zA-Z]+$", message = "campo nombre invalido")//solo acepta letras
    @NotBlank(message="campo nombre invalido")//notblank para string
    @Length(min=4, max=60, message = "minimo 4 caracteres y maximo 60")
    private String nombre;
    
    @Pattern(regexp = "^[a-zA-Z]+$", message = "campo direccion invalido")//solo acepta letras
    @NotBlank(message="campo direccion invalido")//notblank para string
    @Length(min=4, max=70, message = "minimo 4 caracteres y maximo 70")
    @Column(unique = true)
    private String direccion;
     
    @NotNull(message="campo activo invalido")
    @Min(value = 0, message = "El valor debe ser 0 o 1")
    @Max(value = 1, message = "El valor debe ser 0 o 1") 
    private short activo;
    
    @NotNull(message="campo plan invalido")
    private int idPlan; //tipo de plan, verificacion hecha en service
    
    @NotNull(message="campo jefe colegio invalido")
    private int jefeColegio;//verificacion hecha en service
    
    
}