/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nexo.nexoeducativo.service;

import com.nexo.nexoeducativo.models.dto.request.UsuarioDTO;
import com.nexo.nexoeducativo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Martina
 */
@Service
//logica de negocio
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuariorepository;
    
    @Autowired
    private PlanRepository planRepository;
    
    public void crearUsuario(UsuarioDTO u){
        //reglas de negocio, ejemplo campos obligatorios con validaciones
    }
    
     public void crearJefeColegio(UsuarioDTO uDTO){
        
        Usuario u = new Usuario();
        u.setNombre(uDTO.getNombre());
        u.setApellido(uDTO.getApellido());
        u.setEMail(uDTO.geteMail());
        u.setDni(uDTO.getDni());
        u.setActivo((short)1);
        
        this.usuariorepository.save(u);
    }
     
                                //traigo Escuela y Usuario porque el dto combina atributos de ambas entidades
     public void crearEscuela (Escuela e){
        int idPlanDto=e.getIdPlan(); //obtengo id del plan ingresado en el body del Postman
     
        if(escuelaRepository.findByNombre(e.getNombre())){
            //aca salta una excepcion evitando que se guarde la escuela, ver si esta bien el tipo de excepcion
            throw new IllegalArgumentException("la escuela ya existe en la plataforma");
        } else if (!planRepository.existsById(idPlanDto)) {//si se intenta guardar un id de un plan inexistente
            //aca salta una excepcion evitando que se guarde la escuela, ver si esta bien el tipo de excepcion
            throw new IllegalArgumentException("el plan seleccionado no existe");
       } else {
            //si se ingresa un plan existente y el nombre de una escuela que no existe , seguir guardando sino no
             Escuela escuela = new Escuela();
             
             EscuelaUsuario jefeColegio=new EscuelaUsuario();
               escuela.setActivo(e.getActivo());
               escuela.setDireccion(e.getDireccion());
               escuela.setNombre(e.getNombre());
               jefeColegio.setIdEscuelaUsuario(e.getJefeColegio());//guardo el id del jefe colegio en la tabla intermedia
               jefeColegio.setEscuelaIdEscuela(escuela);//ver si esta bien

               // Aquí iría la lógica para guardar la entidad Escuela
               escuelaRepository.save(escuela);
       }
       
     }
    
}
