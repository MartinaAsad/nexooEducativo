package com.nexo.nexoeducativo.repository;

import com.nexo.nexoeducativo.models.entities.Escuela;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EscuelaRepository  extends JpaRepository<Escuela, Integer> {
    boolean findByNombre (String nombre);//metodo que busca a una escuela segun el nombre
}
