package com.nexo.nexoeducativo.repository;

import com.nexo.nexoeducativo.models.entities.EscuelaUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Martina
 */
public interface EscuelaUsuarioRepository extends JpaRepository<EscuelaUsuario, Integer>{
    
}
